# Aurelian Tactics

Submission for Battle Track

Instructions:

* Navigate to directory of "PequilBotCompetitor.py" 
``` python PequilBotRemoteCompetitor.py --id <agent_id>


