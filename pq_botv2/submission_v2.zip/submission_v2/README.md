# Aurelian Tactics

Submission for Battle Track

Instructions:

* Navigate to directory of "PequilBotV2RemoteCompetitor.py" 
``` python PequilBotV2RemoteCompetitor.py --id <agent_id>


